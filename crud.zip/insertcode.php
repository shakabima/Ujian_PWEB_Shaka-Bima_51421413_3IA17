<?php

  $connection = mysqli_connect("localhost","root","");
  $db = mysqli_select_db($connection, 'db_crud');

  if(isset($_POST['insertdata']))
  {
      $nim = $_POST['nim'];
      $nama = $_POST['nama'];
      $alamat = $_POST['alamat'];
      $email = $_POST['email'];
      $jurusan = $_POST['jurusan'];

      $query = "INSERT INTO tbl_mahasiswa (`nim`, `nama`, `alamat`, `email`, `jurusan`)
        VALUES ('$nim','$nama','$alamat','$email','$jurusan')";
      $query_run = mysqli_query($connection, $query);

      if($query_run)
      {
          echo '<script> alert("Data Saved"); </script>';
          header('Location:index.php');
      }
      else
      {
          echo '<script> alert("Data Not Saved"); </script>';
      }
  }

?>
