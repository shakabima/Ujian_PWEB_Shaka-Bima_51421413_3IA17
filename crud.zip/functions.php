<?php

$conn = mysqli_connect("localhost","root","","db_crud");

function query($query) {
  global $conn;
  $result = mysqli_query($conn, $query);
  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
      $rows[] = $row;
  }
  return $rows;
}

function hapus($id) {
  global $conn;
  mysqli_query($conn, "DELETE FROM tbl_mahasiswa WHERE id='$id'");
  return mysqli_affected_rows($conn);
}

function ubah($data) {
  global $conn;

  $id = $data["id"];
  $nim = htmlspecialchars($data["nim"]);
  $nama = htmlspecialchars($data["nama"]);
  $alamat = htmlspecialchars($data["alamat"]);
  $email = htmlspecialchars($data["email"]);
  $jurusan = htmlspecialchars($data["jurusan"]);

  $query = "UPDATE tbl_mahasiswa SET
              nim='$nim',
              nama='$nama',
              alamat='$alamat',
              email='$email',
              jurusan='$jurusan'
            WHERE id='$id'";
  mysqli_query($conn, $query);
  return mysqli_affected_rows($conn);
}

?>
